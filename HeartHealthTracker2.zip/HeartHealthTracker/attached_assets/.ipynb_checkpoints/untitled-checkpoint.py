import yt_dlp

# List of songs with YouTube search URLs (you can replace with actual video URLs for best accuracy)
songs = {
    "Stayin' Alive - Bee Gees": "https://www.youtube.com/results?search_query=Stayin+Alive+Bee+Gees",
    "Another One Bites the Dust - Queen": "https://www.youtube.com/results?search_query=Another+One+Bites+the+Dust+Queen",
    "Baby Shark (chorus)": "https://www.youtube.com/results?search_query=Baby+Shark+song",
    "Crazy Little Thing Called Love - Queen": "https://www.youtube.com/results?search_query=Crazy+Little+Thing+Called+Love+Queen"
}

# yt-dlp options to extract audio and convert to mp3
ydl_opts = {
    'format': 'bestaudio/best',
    'outtmpl': '%(title)s.%(ext)s',
    'postprocessors': [{
        'key': 'FFmpegExtractAudio',
        'preferredcodec': 'mp3',
        'preferredquality': '192',
    }],
    'quiet': False
}

print("Downloading CPR songs as MP3s...\n")

with yt_dlp.YoutubeDL(ydl_opts) as ydl:
    for title, url in songs.items():
        print(f"🔊 Downloading: {title}")
        try:
            ydl.download([url])
        except Exception as e:
            print(f"❌ Failed to download {title}: {e}")

print("\n✅ Done!")
