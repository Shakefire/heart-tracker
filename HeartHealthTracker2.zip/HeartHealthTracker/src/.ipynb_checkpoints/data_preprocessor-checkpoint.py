import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.datasets import fetch_openml
from imblearn.over_sampling import SMOTE
import streamlit as st

class DataPreprocessor:
    def __init__(self):
        self.scaler = StandardScaler()
        self.label_encoders = {}
        self.feature_names = []
        
    def load_cleveland_dataset(self):
        """Load the Cleveland Heart Disease dataset from OpenML"""
        try:
            # Try to load from OpenML
            heart_data = fetch_openml(name='heart-disease', version=1, as_frame=True)
            df = heart_data.frame
            
            # If not available, create a synthetic dataset with realistic features
            if df is None or df.empty:
                raise Exception("Dataset not found")
                
        except:
            # Create synthetic dataset with realistic heart disease features
            st.warning("Using synthetic dataset for demonstration. In production, use real Cleveland Heart Disease dataset.")
            
            np.random.seed(42)
            n_samples = 1000
            
            # Generate realistic heart disease data
            age = np.random.normal(54, 10, n_samples).clip(29, 77)
            sex = np.random.choice([0, 1], n_samples, p=[0.32, 0.68])  # 0=female, 1=male
            cp = np.random.choice([0, 1, 2, 3], n_samples, p=[0.47, 0.16, 0.29, 0.08])  # chest pain type
            trestbps = np.random.normal(131, 17, n_samples).clip(94, 200)  # resting blood pressure
            chol = np.random.normal(246, 52, n_samples).clip(126, 564)  # cholesterol
            fbs = np.random.choice([0, 1], n_samples, p=[0.85, 0.15])  # fasting blood sugar
            restecg = np.random.choice([0, 1, 2], n_samples, p=[0.48, 0.48, 0.04])  # resting ECG
            thalach = np.random.normal(150, 23, n_samples).clip(71, 202)  # max heart rate
            exang = np.random.choice([0, 1], n_samples, p=[0.68, 0.32])  # exercise induced angina
            oldpeak = np.random.exponential(1, n_samples).clip(0, 6.2)  # ST depression
            slope = np.random.choice([0, 1, 2], n_samples, p=[0.21, 0.50, 0.29])  # slope of peak exercise ST
            ca = np.random.choice([0, 1, 2, 3], n_samples, p=[0.59, 0.25, 0.12, 0.04])  # number of major vessels
            thal = np.random.choice([0, 1, 2, 3], n_samples, p=[0.02, 0.18, 0.18, 0.62])  # thalassemia
            
            # Create target variable with realistic correlations
            risk_score = (
                0.1 * age + 
                0.3 * sex + 
                0.2 * cp + 
                0.1 * (trestbps > 140) + 
                0.1 * (chol > 240) +
                0.2 * fbs + 
                0.1 * restecg +
                -0.2 * (thalach > 150) +
                0.3 * exang +
                0.2 * oldpeak +
                0.1 * slope +
                0.2 * ca +
                0.2 * thal +
                np.random.normal(0, 0.5, n_samples)
            )
            
            target = (risk_score > np.median(risk_score)).astype(int)
            
            df = pd.DataFrame({
                'age': age.astype(int),
                'sex': sex,
                'cp': cp,
                'trestbps': trestbps.astype(int),
                'chol': chol.astype(int),
                'fbs': fbs,
                'restecg': restecg,
                'thalach': thalach.astype(int),
                'exang': exang,
                'oldpeak': oldpeak,
                'slope': slope,
                'ca': ca,
                'thal': thal,
                'target': target
            })
        
        return df
    
    def preprocess_data(self, df):
        """Preprocess the heart disease dataset"""
        # Separate features and target
        X = df.drop('target', axis=1)
        y = df['target']
        
        # Store feature names
        self.feature_names = X.columns.tolist()
        
        # Handle missing values
        X = X.fillna(X.median())
        
        # Encode categorical variables if any
        categorical_features = X.select_dtypes(include=['object']).columns
        for feature in categorical_features:
            le = LabelEncoder()
            X[feature] = le.fit_transform(X[feature].astype(str))
            self.label_encoders[feature] = le
        
        # Convert to numpy arrays
        X = X.values.astype(np.float32)
        y = y.values.astype(np.int32)
        
        return X, y
    
    def apply_smote(self, X, y):
        """Apply SMOTE for handling class imbalance"""
        smote = SMOTE(random_state=42)
        X_resampled, y_resampled = smote.fit_resample(X, y)
        return X_resampled, y_resampled
    
    def scale_features(self, X_train, X_test=None):
        """Scale features using StandardScaler"""
        X_train_scaled = self.scaler.fit_transform(X_train)
        
        if X_test is not None:
            X_test_scaled = self.scaler.transform(X_test)
            return X_train_scaled, X_test_scaled
        
        return X_train_scaled
    
    def load_and_preprocess_data(self, test_size=0.2, apply_smote=True):
        """Complete data loading and preprocessing pipeline"""
        # Load dataset
        df = self.load_cleveland_dataset()
        
        # Preprocess
        X, y = self.preprocess_data(df)
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=42, stratify=y
        )
        
        # Apply SMOTE to training data only
        if apply_smote:
            X_train, y_train = self.apply_smote(X_train, y_train)
        
        # Scale features
        X_train_scaled, X_test_scaled = self.scale_features(X_train, X_test)
        
        return X_train_scaled, X_test_scaled, y_train, y_test
    
    def prepare_input_for_prediction(self, input_data):
        """Prepare user input for model prediction"""
        # Convert input to numpy array
        input_array = np.array(input_data).reshape(1, -1)
        
        # Scale the input
        input_scaled = self.scaler.transform(input_array)
        
        return input_scaled
    
    def get_feature_names(self):
        """Get feature names for interpretability"""
        return self.feature_names
